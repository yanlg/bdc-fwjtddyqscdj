import _ from 'lodash';
function sayName (){
	console.log('this is production page');
};
sayName();